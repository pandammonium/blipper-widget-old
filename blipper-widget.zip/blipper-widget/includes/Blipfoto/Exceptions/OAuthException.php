<?php

/**
* For OAuth.
**/

namespace blipper_widget_Blipfoto\blipper_widget_Exceptions;

// If this file is called directly, abort.
defined( 'ABSPATH' ) or die();
defined( 'WPINC' ) or die();

use blipper_widget_Blipfoto\blipper_widget_Exceptions\blipper_widget_BaseException;

class blipper_widget_OAuthException extends blipper_widget_BaseException {
	
}