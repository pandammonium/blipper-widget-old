<?php

/**
* For connectivity issues.
**/

namespace blipper_widget_Blipfoto\blipper_widget_Exceptions;

// If this file is called directly, abort.
defined( 'ABSPATH' ) or die();
defined( 'WPINC' ) or die();

use blipper_widget_Blipfoto\blipper_widget_Exceptions\blipper_widget_BaseException;

class blipper_widget_NetworkException extends blipper_widget_BaseException {
	
}